import pygame
from sys import exit
from random import randint

def display_score():
    current_time = str(pygame.time.get_ticks() - start_time)[:-2]
    score_surface = font.render('Score : '+current_time, False, (64,64,64))
    score_rect = score_surface.get_rect(center = (400, 50))
    screen.blit(score_surface,score_rect)
    return current_time

def obstacle_movement(obstacles_list):
    if obstacles_list:
        for obstacles_rect in obstacles_rect_list:
            obstacles_rect.x -= 6
            if obstacles_rect.bottom == 300:screen.blit(snail_surface, obstacles_rect)
            else:screen.blit(fly_surface, obstacles_rect)
        obstacles_list = [obstacles for obstacles in obstacles_list if obstacles.x > -100]
        return obstacles_list
    else:return []

def collisions(player, obstacles):
    if obstacles:
        for obstacle_rect in obstacles:
            if player.colliderect(obstacle_rect): return False
    return True

def player_animation():
    global player_index, player_surface
    if player_rect.bottom < 300 :
        player_surface = player_jump
    else:
        player_index += 0.1
        if player_index >= len(player_walk): player_index = 0
        player_surface = player_walk[int(player_index)]

pygame.init()
screen = pygame.display.set_mode((800, 400)) #set window size
pygame.display.set_caption('JustRun') #set window title
clock = pygame.time.Clock()
font = pygame.font.Font('font/Pixeltype.ttf', 50) #making font style

sky_surface = pygame.image.load('graphics/Sky.png').convert()  #importing image as inner sirface for sky
land_surface = pygame.image.load('graphics/ground.png').convert()  #importing image as inner sirface for ground
player_walk1 = pygame.image.load('graphics/player/player_walk_1.png').convert_alpha()
player_walk2 = pygame.image.load('graphics/player/player_walk_2.png').convert_alpha()
player_walk = [player_walk1,player_walk2]
player_index = 0
player_jump = pygame.image.load('graphics/player/jump.png').convert_alpha()
player_surface = player_walk[player_index]
player_rect = player_surface.get_rect(midbottom = (80, 300))

#obstacles
#snail
snail_frame1 = pygame.image.load('graphics/snail/snail1.png').convert_alpha()
snail_frame2 = pygame.image.load('graphics/snail/snail2.png').convert_alpha()
snail_frames = [snail_frame1, snail_frame2]
snail_index = 0
snail_surface = snail_frames[snail_index]

#fly
fly_frame1 = pygame.image.load('graphics/fly/fly1.png').convert_alpha()
fly_frame2 = pygame.image.load('graphics/fly/fly2.png').convert_alpha()
fly_frames = [fly_frame1, fly_frame2]
fly_index = 0
fly_surface = fly_frames[fly_index]
obstacles_rect_list = []

player_gravity = 0
game_active = False
start_time = 0
score = 0

#intro screen
player_stand = pygame.image.load('graphics/player/player_stand.png').convert_alpha()
player_stand = pygame.transform.scale2x(player_stand)
player_stand_rect = player_stand.get_rect(center = (400,200))

#Text
game_name = font.render('Pixel Runner', False, (111,196,169))
game_name_rect = game_name.get_rect(center = (400,80))
game_message = font.render('Press Space to start', False, (111, 196, 169))
game_message_rect = game_message.get_rect(center = (400, 350))

#Timer
obstacle_timer = pygame.USEREVENT + 1
pygame.time.set_timer(obstacle_timer, 1400)
snail_timer = pygame.USEREVENT + 2
pygame.time.set_timer(snail_timer, 500)
fly_timer = pygame.USEREVENT + 3
pygame.time.set_timer(fly_timer, 200)

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        if game_active:
            if event.type == pygame.MOUSEBUTTONDOWN:
                if player_rect.collidepoint(event.pos) and player_rect.bottom >= 300:
                    player_gravity = -20
            if event.type == pygame.KEYDOWN: 
                if (event.key == pygame.K_SPACE or event.key == pygame.K_UP) and player_rect.bottom>= 300:
                    player_gravity = -20
        else:
           if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
               game_active = True
               start_time = pygame.time.get_ticks()
        if game_active:
            if event.type == obstacle_timer:
                if randint(0,2):
                    obstacles_rect_list.append(snail_surface.get_rect(midbottom = (randint(900,1100),300)))
                else:
                    obstacles_rect_list.append(fly_surface.get_rect(midbottom = (randint(900,1100),210)))
            if event.type == snail_timer:
                if snail_index == 0: snail_index = 1
                else: snail_index = 0
                snail_surface = snail_frames[snail_index]
            if event.type == fly_timer:
                if fly_index == 0: fly_index = 1
                else: fly_index = 0
                fly_surface = fly_frames[fly_index]

    if game_active:        
        screen.blit(sky_surface,(0,0))
        screen.blit(land_surface, (0,300))
        score = display_score()

        #player
        player_gravity += 1
        player_rect.y += player_gravity
        if player_rect.bottom >= 300: player_rect.bottom = 300
        player_animation()
        screen.blit(player_surface, player_rect)
        obstacles_rect_list = obstacle_movement(obstacles_rect_list)
        game_active = collisions(player_rect,obstacles_rect_list)

    else:
        screen.fill((94,129,162))
        screen.blit(player_stand, player_stand_rect)
        obstacles_rect_list.clear()
        player_rect.midbottom = (80, 300)
        player_gravity = 0
        score_message = font.render(f'Your Score: {score}', False, (111,196,169))
        score_message_rect = score_message.get_rect(center = (400, 320))
        screen.blit(game_name ,game_name_rect)
        if score == 0:screen.blit(game_message, game_message_rect)
        else:
            screen.blit(game_message, game_message_rect)
            screen.blit(score_message, score_message_rect)
    pygame.display.update()
    clock.tick(60)